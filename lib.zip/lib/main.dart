import 'package:flutter/material.dart';
import 'screens/login_screen.dart';
import 'screens/product_list_screen.dart';
import 'screens/product_register_screen.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'App Produtos',
      debugShowCheckedModeBanner: false,
      initialRoute: '/login',
      routes: {
        '/login': (_) => const LoginScreen(),
        '/products': (_) => const ProductListScreen(),
        '/register': (_) => const ProductRegisterScreen(),
      },
      theme: ThemeData(
        fontFamily: 'Roboto',
        useMaterial3: true,
      ),
    );
  }
}